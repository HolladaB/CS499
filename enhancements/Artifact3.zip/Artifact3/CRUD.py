#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user, password):
        # Initializing the MongoClient.
        # Connection Variables
        USER = user
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 34136
        DB = 'AAC'
        COL = 'animals'

        # Initialize Connection
        try:
            self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
            self.database = self.client['%s' % (DB)]
            self.collection = self.database['%s' % (COL)]
        except Exception as e:
            raise Exception("Error connecting to database")

# Implement the C in CRUD
    def create(self, data):
        if data is not None:
            result = self.collection.insert_one(data)  # data should be dictionary            
            return result.acknowledged # used to return true is insert is successful
        else:
            raise Exception("Nothing to save, because data parameter is empty") #throws exception if no data to insert
            return false

# Implement the R in CRUD.
    def read(self, query):
        try:
            cursor = self.collection.find(query) #uses input to search data
            if cursor is not None: #if input is found in data returns the cursor as a list
                return list(cursor)
            else: 
                return [] # if the input is not found, a empty list is returned
        except Exception as e:
            print("Error reading database") # throws exception if data cant be searched
            return[]
        
# Implement the U in CRUD.        
    def update(self, search, change):
        if search is not None:
            results = self.collection.update_many(search, {"$set" : change})  # keeps track of changes  
            total = results.modified_count
            print(total, " documents modified.")
            return total # used to return number of modified documents
        else:
            raise Exception("Error with update!") #throws exception if no query data provided
            return

# Implement the D in CRUD.        
    def delete(self, data):
        if data is not None:
            results = self.collection.delete_many(data)  # keeps track of changes  
            total = results.deleted_count
            print(total, " documents deleted.")
            return total # used to return number of modified documents
        else:
            raise Exception("Error with delete!") #throws exception if no query data provided
            return
                

